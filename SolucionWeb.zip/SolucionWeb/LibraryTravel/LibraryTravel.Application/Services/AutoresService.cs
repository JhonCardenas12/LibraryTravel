﻿using LibraryTravel.Application.Interfaces;
using LibraryTravel.Application.ViewModels;
using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Domain.Models;
using System.Collections.Generic;

namespace LibraryTravel.Application.Services
{
    public class AutoresService : IAutoresService
    {
        public IAutoresRepository autoresRepository;
        public AutoresService(IAutoresRepository autoresRepository)
        {
            this.autoresRepository = autoresRepository;
        }

        public Autores CreateAutores(Autores autores)
        {
            return this.autoresRepository.CreateAutores(autores);
        }

        public void DeleteAutor(int id)
        {
            this.autoresRepository.DeleteAutor(id);
        }

        public Autores GetAutor(int id)
        {
            return this.autoresRepository.GetAutor(id);
        }

        public AutoresViewModel GetAutores()
        {
            return new AutoresViewModel()
            {
                Autores = autoresRepository.GetAutores()
            };
        }

        public IEnumerable<Autores> GetAutoresAll()
        {
            return autoresRepository.GetAutoresAll();
        }

        public Autores UpdateAutores(Autores autores)
        {
            return this.autoresRepository.UpdateAutores(autores);
        }
    }
}
