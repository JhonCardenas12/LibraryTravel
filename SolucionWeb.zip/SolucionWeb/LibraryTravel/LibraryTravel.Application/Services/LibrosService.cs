﻿using LibraryTravel.Application.Interfaces;
using LibraryTravel.Application.ViewModels;
using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Domain.Models;

namespace LibraryTravel.Application.Services
{
    public class LibrosService : ILibrosService
    {
        public ILibrosRepository librosRepository;
        public LibrosService(ILibrosRepository librosRepository)
        {
            this.librosRepository = librosRepository;
        }

        public Libros CreateLibro(Libros libros)
        {
            return this.librosRepository.CreateLibro(libros);
        }

        public void DeleteLibro(int id)
        {
            this.librosRepository.DeleteLibro(id);
        }

        public Libros GetLibro(int id)
        {
            return this.librosRepository.GetLibro(id);
        }

        public LibrosViewModel GetLibros()
        {
            return new LibrosViewModel
            {
                Libros = this.librosRepository.GetLibros()
            };
        }

        public Libros UpdateLibro(Libros libros)
        {
            return this.librosRepository.UpdateLibro(libros);
        }
    }
}
