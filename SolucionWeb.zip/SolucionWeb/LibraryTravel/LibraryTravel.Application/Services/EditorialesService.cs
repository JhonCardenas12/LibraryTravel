﻿using LibraryTravel.Application.Interfaces;
using LibraryTravel.Application.ViewModels;
using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Domain.Models;
using System.Collections.Generic;

namespace LibraryTravel.Application.Services
{
    public class EditorialesService : IEditorialesService
    {
        public IEditorialesRepository editorialesRepository;
        public EditorialesService(IEditorialesRepository editorialesRepository)
        {
            this.editorialesRepository = editorialesRepository;
        }

        public Editoriales CreateEditoriales(Editoriales editoriales)
        {
            return this.editorialesRepository.CreateEditoriales(editoriales);
        }

        public void DeleteEditoriales(int id)
        {
            this.editorialesRepository.DeleteEditoriales(id);
        }

        public Editoriales GetEditorial(int EditorialeId)
        {
            return editorialesRepository.GetEditorial(EditorialeId);
        }

        public EditorialesViewModel GetEditoriales()
        {
            return new EditorialesViewModel()
            {
                Editoriales = editorialesRepository.GetEditoriales()
            };
        }

        public IEnumerable<Editoriales> GetEditorialesAll()
        {
            return editorialesRepository.GetEditorialesAll();
        }

        public Editoriales UpdateEditoriales(Editoriales editoriales)
        {
            return this.editorialesRepository.UpdateEditoriales(editoriales);
        }
    }
}
