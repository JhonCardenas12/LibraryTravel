﻿using LibraryTravel.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryTravel.Application.ViewModels
{
    public class EditorialesViewModel
    {
        public IEnumerable<Editoriales> Editoriales { get; set; }
    }
}
