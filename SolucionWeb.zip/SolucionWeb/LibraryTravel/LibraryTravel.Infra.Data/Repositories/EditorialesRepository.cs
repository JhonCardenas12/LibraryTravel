﻿using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Domain.Models;
using LibraryTravel.Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryTravel.Infra.Data.Repositories
{
    public class EditorialesRepository : IEditorialesRepository
    {
        public LibraryDbContext context;
        public EditorialesRepository(LibraryDbContext context)
        {
            this.context = context;
        }

        public Editoriales CreateEditoriales(Editoriales editoriales)
        {
            context.Editoriales.Add(editoriales);
            context.SaveChanges();
            return editoriales;
        }

        public void DeleteEditoriales(int id)
        {
            Editoriales editoriales = new Editoriales();
            editoriales = context.Editoriales.Where(x => x.Id == id).FirstOrDefault();
            context.Editoriales.Remove(editoriales);
            context.SaveChanges();
        }

        public Editoriales GetEditorial(int editorialeId)
        {
            return context.Editoriales.Where(x => x.Id == editorialeId).FirstOrDefault();
        }

        public IEnumerable<Editoriales> GetEditoriales()
        {
            return context.Editoriales;
        }

        public IEnumerable<Editoriales> GetEditorialesAll()
        {
            return context.Editoriales;
        }

        public Editoriales UpdateEditoriales(Editoriales editoriales)
        {
            context.Entry(editoriales).State = EntityState.Modified;
            context.SaveChanges();
            return editoriales;
        }
    }
}
