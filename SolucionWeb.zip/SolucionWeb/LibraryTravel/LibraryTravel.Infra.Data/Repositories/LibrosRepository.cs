﻿using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Domain.Models;
using LibraryTravel.Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryTravel.Infra.Data.Repositories
{
    public class LibrosRepository : ILibrosRepository
    {
        public LibraryDbContext context;
        public LibrosRepository(LibraryDbContext context)
        {
            this.context = context;
        }
        public IEnumerable<Libros> GetLibros()
        {
            return context.Libros;
        }
        public Libros GetLibro(int id)
        {
            return context.Libros.Where(x => x.ISBN == id).FirstOrDefault();
        }
        public Libros CreateLibro(Libros libros)
        {
            context.Libros.Add(libros);
            context.SaveChanges();
            return libros;
        }
        public Libros UpdateLibro(Libros libros)
        {
            context.Entry(libros).State = EntityState.Modified;
            context.SaveChanges();
            return libros;
        }
        public void DeleteLibro(int Id)
        {
            Libros libros = new Libros();
            libros = context.Libros.Where(x => x.ISBN == Id).FirstOrDefault();
            context.Libros.Remove(libros);
            context.SaveChanges();
        }
    }
}
