﻿using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Domain.Models;
using LibraryTravel.Infra.Data.Context;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace LibraryTravel.Infra.Data.Repositories
{
    public class AutoresRepository : IAutoresRepository
    {
        public LibraryDbContext context;
        public AutoresRepository(LibraryDbContext context)
        {
            this.context = context;
        }

        public Autores CreateAutores(Autores autores)
        {
            context.Autores.Add(autores);
            context.SaveChanges();
            return autores;
        }

        public void DeleteAutor(int id)
        {
            Autores autores = new Autores();
            autores = context.Autores.Where(x => x.Id == id).FirstOrDefault();
            context.Autores.Remove(autores);
            context.SaveChanges();
        }

        public Autores GetAutor(int id)
        {
            return context.Autores.Where(x => x.Id == id).FirstOrDefault();
        }

        public IEnumerable<Autores> GetAutores()
        {
            return context.Autores;
        }

        public IEnumerable<Autores> GetAutoresAll()
        {
            return context.Autores;
        }

        public Autores UpdateAutores(Autores autores)
        {
            context.Entry(autores).State = EntityState.Modified;
            context.SaveChanges();
            return autores;
        }
    }
}
