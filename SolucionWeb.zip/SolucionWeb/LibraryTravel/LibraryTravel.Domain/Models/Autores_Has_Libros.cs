﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryTravel.Domain.Models
{
    public class Autores_Has_Libros
    {
        [Key]
        [Column(Order = 0)]
        public int Autores_Id { get; set; }
        [Key]
        [Column(Order = 1)]
        public int Libros_ISBN { get; set; }
    }
}
