﻿using LibraryTravel.Domain.Models;
using System.Collections.Generic;

namespace LibraryTravel.Domain.Interfaces
{
    public interface IAutor_Has_LibrosRepository
    {
        Autores_Has_Libros CreateAutor_Libro(int AutorId, int ISBN);
    }
}
