﻿using LibraryTravel.Domain.Models;
using System.Collections.Generic;

namespace LibraryTravel.Domain.Interfaces
{
    public interface ILibrosRepository
    {
        IEnumerable<Libros> GetLibros();
        Libros GetLibro(int id);
        Libros CreateLibro(Libros libros);
        Libros UpdateLibro(Libros libros);
        void DeleteLibro(int Id);
    }
}
