﻿using LibraryTravel.Domain.Models;
using System.Collections.Generic;

namespace LibraryTravel.Domain.Interfaces
{
    public interface IAutoresRepository
    {
        IEnumerable<Autores> GetAutores();
        IEnumerable<Autores> GetAutoresAll();
        Autores CreateAutores(Autores autores);
        void DeleteAutor(int id);
        Autores GetAutor(int id);
        Autores UpdateAutores(Autores autores);
    }
}
