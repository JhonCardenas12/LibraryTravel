﻿using LibraryTravel.Application.Interfaces;
using LibraryTravel.Application.Services;
using LibraryTravel.Domain.Interfaces;
using LibraryTravel.Infra.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;


namespace LibraryTravel.Infra.IoC
{
    public class DependencyContainer
    {
        public static void RegisterServices(IServiceCollection services)
        {
            //Autores
            services.AddScoped<IAutoresService, AutoresService>();
            services.AddScoped<IAutoresRepository, AutoresRepository>();
            //Libros
            services.AddScoped<ILibrosService, LibrosService>();
            services.AddScoped<ILibrosRepository, LibrosRepository>();
            //Editoriales
            services.AddScoped<IEditorialesService, EditorialesService>();
            services.AddScoped<IEditorialesRepository, EditorialesRepository>();
            //Autores has libros
            services.AddScoped<IAutores_Has_LibrosServices, AutoresLibrosService>();
            services.AddScoped<IAutor_Has_LibrosRepository, AutoresHasLibrosRepository>();

        }
    }
}
