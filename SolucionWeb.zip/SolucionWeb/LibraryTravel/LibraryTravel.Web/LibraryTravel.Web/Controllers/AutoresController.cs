﻿using LibraryTravel.Application.Interfaces;
using LibraryTravel.Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryTravel.Web.Controllers
{
    [Authorize]
    public class AutoresController : Controller
    {
        private IAutoresService autoresService;
        public AutoresController(IAutoresService autoresService)
        {
            this.autoresService = autoresService;
        }
        // GET: ProjectController
        public ActionResult Index()
        {
            return View(this.autoresService.GetAutores());
        }
        // GET: LibrosController/Details/5
        public ActionResult Details(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            return View(this.autoresService.GetAutor(id));
        }
        // GET: LibrosController/Create
        public ActionResult Create()
        {
            return View();
        }
        // POST: LibrosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Autores autores)
        {
            if (ModelState.IsValid)
            {
                this.autoresService.CreateAutores(autores);
                return RedirectToAction("Index");
            }
            return View(autores);
        }
        // GET: LibrosController/Edit/5
        public ActionResult Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            return View(this.autoresService.GetAutor(id));
        }
        // POST: LibrosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Autores autores)
        {
            if (ModelState.IsValid)
            {
                this.autoresService.UpdateAutores(autores);
                return RedirectToAction("Index");
            }
            return View(autores);
        }
        // GET: LibrosController/Delete/5
        public ActionResult Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            return View(this.autoresService.GetAutor(id));
        }
        // POST: LibrosController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            this.autoresService.DeleteAutor(id);
            return RedirectToAction("Index");
        }

    }
}