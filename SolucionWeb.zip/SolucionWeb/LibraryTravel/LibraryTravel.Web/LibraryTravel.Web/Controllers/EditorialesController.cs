﻿using LibraryTravel.Application.Interfaces;
using LibraryTravel.Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LibraryTravel.Web.Controllers
{
    [Authorize]
    public class EditorialesController : Controller
    {
        private IEditorialesService editorialesService;
        public EditorialesController(IEditorialesService editorialesService)
        {
            this.editorialesService = editorialesService;
        }
        // GET: ProjectController
        public ActionResult Index()
        {
            return View(this.editorialesService.GetEditoriales());
        }
        // GET: LibrosController/Details/5
        public ActionResult Details(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            return View(this.editorialesService.GetEditorial(id));
        }
        // GET: LibrosController/Create
        public ActionResult Create()
        {
            return View();
        }
        // POST: LibrosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Editoriales editoriales)
        {
            if (ModelState.IsValid)
            {
                this.editorialesService.CreateEditoriales(editoriales);
                return RedirectToAction("Index");
            }
            return View(editoriales);
        }
        // GET: LibrosController/Edit/5
        public ActionResult Edit(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            return View(this.editorialesService.GetEditorial(id));
        }
        // POST: LibrosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Editoriales editoriales)
        {
            if (ModelState.IsValid)
            {
                this.editorialesService.UpdateEditoriales(editoriales);
                return RedirectToAction("Index");
            }
            return View(editoriales);
        }
        // GET: LibrosController/Delete/5
        public ActionResult Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            return View(this.editorialesService.GetEditorial(id));
        }
        // POST: LibrosController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (id == 0)
            {
                return BadRequest("El id no puede ser nulo.");
            }
            this.editorialesService.DeleteEditoriales(id);
            return RedirectToAction("Index");
        }

    }
}